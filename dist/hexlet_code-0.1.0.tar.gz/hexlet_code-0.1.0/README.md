### Hexlet tests and linter status:
[![Actions Status](https://github.com/kirillmark/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/kirillmark/python-project-49/actions)

<a href="https://codeclimate.com/github/kirillmark/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0ce596cb7972f0c01b83/maintainability" /></a>
